package com.crazyputting3d.UI;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.crazyputting3d.Engine.physicsEngine;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.sun.org.apache.xml.internal.dtm.ref.DTMAxisIterNodeList;


public class MenuScreen implements Screen {
    private Skin skin;
    private Stage stage;
    private TextButton play;
    private TextButton playBot;
    private TextButton settings;
    private TextButton simulator;
    private Dialog dialogBot;
    private Dialog dialogSolver;
    private SelectBox<String> botSelect;
    private SelectBox<String> solverSelect;
    private TextArea textField;
    private Table title;
    private Table quit;
    private TextButton quitButton;


    private Texture background;
    private Image splashImage;

    private LevelScreen levelScreen = new LevelScreen();


    public MenuScreen(){
        stage = new Stage();
        Gdx.input.setInputProcessor(stage);
    }




    @Override
    public void show() {
        Table table = new Table();
        table.setPosition(300,170);

        background = new Texture("title6.jpeg");
        splashImage = new Image(background);

        stage.addActor(splashImage);

        Table table1 = new Table();
        table1.setPosition(110,150);
        stage.addActor(table);
        stage.addActor(table1);





        skin = new Skin(Gdx.files.internal("skin/freezing-ui.json"));

        textField= new TextArea("Crazy Putting 3D!", skin);
        title = new Table();
        title.setPosition(120,300);
        title.add(textField);
        stage.addActor(title);

        quit = new Table();
        quit.setPosition(80,30);
        quitButton = new TextButton("Quit", skin);
        quit.add(quitButton);
        stage.addActor(quit);

        play = new TextButton("Play",skin);
        playBot = new TextButton("PlayBot",skin);
        settings = new TextButton("Settings", skin);
        simulator = new TextButton("Simulator", skin);

       // dialogBot = new Dialog("Select Bot and Solver", skin);
        //dialogBot.setSize(250,150);
        botSelect = new SelectBox<String>(skin);
        botSelect.setItems("Hill Climbing", "Newton Raphson", "Random Based", "Rule Based", "Brute Force");
        //dialogBot.getContentTable().add(botSelect);
        //dialogBot.getContentTable().row();
        solverSelect = new SelectBox<String>(skin);
        solverSelect.setItems("Eulers Method", "Runge-Kutta 2", "Runge-Kutta 4", "Dormand Prince", "Verlets Method", "Predictor corrector");
        //dialogBot.getContentTable().add(solverSelect);
        //dialogBot.setPosition(40,40);
        //table1.add(dialogBot).pad(40,40,40,40);
       // stage.addActor(dialogBot);
        //dialogBot.show(stage).setPosition(0,0);
        table1.add(botSelect);
        table1.row().pad(10,0,10,0);
        table1.add(solverSelect);




        table.add(play).fillX().uniformX();
        table.row().pad(10,0,10,0);
        table.add(playBot).fillX().uniformX();
        table.row();
        table.add(simulator);
        table.row().pad(10,0,10,0);
        table.add(settings);


        play.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
//              System.out.println("it works");
//
//                physicsEngine.solvernum = solverSelect.getSelectedIndex();
//
//                Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
//                config.setForegroundFPS(60);
//                config.setTitle("Crazy Putting!");
//                config.setWindowedMode(1280,720);
//                new Lwjgl3Application(new game3d(true,false,botSelect.getSelectedIndex()), config);

                ((Game)Gdx.app.getApplicationListener()).setScreen(levelScreen);
            }


        });
        playBot.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                physicsEngine.solvernum = solverSelect.getSelectedIndex();

                Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
                config.setForegroundFPS(60);
                config.setTitle("Crazy Putting!");
                config.setWindowedMode(1280,720);
                new Lwjgl3Application(new game3d(false,true,botSelect.getSelectedIndex()), config);
            }
        });
        simulator.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                physicsEngine.solvernum = solverSelect.getSelectedIndex();

                Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
                config.setForegroundFPS(60);
                config.setTitle("Crazy Putting!");
                config.setWindowedMode(1280,720);
                new Lwjgl3Application(new game3d(false,false,botSelect.getSelectedIndex()), config);
            }
        });
        quit.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                Gdx.app.exit();
            }
        });
    }

    @Override
    public void render(float delta) {

        Gdx.gl.glClearColor(0,0,0,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        stage.act(Math.min(Gdx.graphics.getDeltaTime(),1/30f));
        stage.draw();


//
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
