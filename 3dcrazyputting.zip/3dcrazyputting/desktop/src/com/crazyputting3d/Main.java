package com.crazyputting3d;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import com.crazyputting3d.Engine.physicsEngine;
import com.crazyputting3d.UI.Menu;
import com.crazyputting3d.UI.MenuTest;
import com.crazyputting3d.UI.game3d;

/**
 * This is the main class. To run the program, run the
 * main method of this class. 
 * Authors: Casper Bröcheler, Guilherme Pereira Sequeira, Alina Gavrish, Arjen van
 * Gelder, Trinh Le, Gabrijel Radovčić, Elza Strazda
 * version 2.0
 * since 2022-05-11
 */

public class Main {
    public static void main(String[] args) {
//        Menu start_up = new Menu();
//        start_up.run();

        physicsEngine.solvernum = 0;
        Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
        config.setForegroundFPS(60);
        config.setTitle("Crazy Putting!");
        config.setWindowedMode(1280,720);
        new Lwjgl3Application(new game3d(true,false,0), config);
    }
}
