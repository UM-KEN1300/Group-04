package com.crazyputting3d.InputReader;
public class Function{
public double getHeightFunction(double x, double y){
 return 0.4*(0.9-Math.exp(-(Math.pow(x,2)+Math.pow(y,2))/8));
}
}
